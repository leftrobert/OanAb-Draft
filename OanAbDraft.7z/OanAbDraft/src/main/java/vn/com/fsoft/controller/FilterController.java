package vn.com.fsoft.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import vn.com.fsoft.dao.ShirtDAO;
import vn.com.fsoft.model.Shirt;

@Controller
public class FilterController{
	@RequestMapping(value = "/handlingFilter", method=RequestMethod.POST)
	public String handlingFilter(HttpServletRequest arg0, HttpServletResponse arg1m, RedirectAttributes redirectAttributes,
			@RequestParam("cat") String cat, @RequestParam("gen") String gen, @RequestParam("mat") String mat, @RequestParam("size") String siz, @RequestParam("low") String low, @RequestParam("high") String hig, @RequestParam("sort") String sor, HttpSession session){
		// TODO Auto-generated method stub
//		ShirtDAO shirtDao = new ShirtDAO();
//		List<Shirt> listshirt = shirtDao.getList();
//		List<Shirt> listtrend = shirtDao.getTrendingList();
//		List<Shirt> listhot = shirtDao.getHotList();
//		System.out.println("cat = " + cat + ", gen = " + gen + ", mat = " + mat + ", siz = " + siz + ", low = " + low + ", hig = " + hig + ", sor = " + sor);
//		List<Shirt> listfilter = shirtDao.getFilteredList(cat, gen, mat, siz, low, hig, sor);
//		session.setAttribute("list_filter", listfilter);
//		session.setAttribute("list_shirt", listshirt);
//		session.setAttribute("list_trend", listtrend);
//		session.setAttribute("list_hot", listhot);
//		if (session.getAttribute("from") == null || !session.getAttribute("from").equals("filter")) session.setAttribute("from", "filter");
//		System.out.println(session.getAttribute("from"));
		return "redirect:shop";
	}
}
