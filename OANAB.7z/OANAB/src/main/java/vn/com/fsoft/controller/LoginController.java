package vn.com.fsoft.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import vn.com.fsoft.dao.LoginDAO;
import vn.com.fsoft.dao.UserDAO;
import vn.com.fsoft.model.User;

@Controller
public class LoginController{
	@RequestMapping(value = "/handlingLogin", method=RequestMethod.POST)
	public String handlingLogin(HttpServletRequest arg0, HttpServletResponse arg1m,RedirectAttributes redirectAttributes,
	@RequestParam("loginid") String user,@RequestParam("loginpw") String pass, HttpSession session){
		System.out.println("login: "+user+" "+pass);
		// TODO Auto-generated method stub
		LoginDAO loginDAO = new LoginDAO();
		UserDAO userDao = new UserDAO();
		if(user == "" || pass == "") {
			session.setAttribute("message", "1");
//			System.out.println(session.getAttribute("message"));
			return "redirect:login";}
		else if(loginDAO.checkLogin(user, pass)){
			List<User> list = loginDAO.getInforIfLoginSucess(user);
			session.setAttribute("name", list.get(0).getName());
			List<User> listuser = userDao.getList();
			session.setAttribute("list_user", listuser);
			session.setAttribute("page", "1");
			System.out.println(session.getAttribute("name"));
			return "redirect:import";
		}
		else{
//			redirectAttributes.addFlashAttribute("notify","Tài khoản hoặc mật khẩu bị sai.");
			session.setAttribute("message", "2");
//			System.out.println(session.getAttribute("message"));
			return "redirect:login";
		}
	}
}
