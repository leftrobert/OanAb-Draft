package vn.com.fsoft.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lib.StringLib;
import vn.com.fsoft.dao.LoginDAO;
import vn.com.fsoft.dao.UserDAO;
import vn.com.fsoft.model.User;

@Controller
public class PublicAccountController{
	@RequestMapping(value = "/account", method=RequestMethod.GET)
	public ModelAndView displayAccount(HttpServletRequest arg0, HttpServletResponse arg1, HttpSession session){
		// TODO Auto-generated method stub
		return new ModelAndView("account");
	}
	@RequestMapping(value = "/updateUser", method=RequestMethod.POST)
	public String handlingLogin(HttpServletRequest arg0, HttpServletResponse arg1m,RedirectAttributes redirectAttributes,
		@RequestParam("name") String name, @RequestParam("phone") String phone,@RequestParam("gender") String gender,@RequestParam("dob") String date,@RequestParam("address") String address, HttpSession session){
		if (session.getAttribute("loggedin") != null) {
			User u = (User)session.getAttribute("loggedin");
			System.out.println(u.toString());
			System.out.println(" name "+name+" phone "+phone+" gender: "+gender+" date:"+date+" address:"+address);
			if(!"".equals(name)&&!"".equals(phone)&&!"".equals(gender)&&!"".equals(address)) {
				//String id, String password, String name, String phone, boolean gender, String dob, String address,
				//String regDate, String favoriteCat, boolean status
				Boolean genderB = Boolean.valueOf(gender);
				User item = new User(u.getId(),u.getPassword(),name,phone,genderB,date,address,u.getRegDate(),u.getFavoriteCat(),u.isStatus());
				UserDAO uDao = new UserDAO();
				uDao.updateUser(item);
				LoginDAO ldao = new LoginDAO();
				User user = ldao.getUser(phone);
				session.setAttribute("loggedin", user);
				
			}
		}
		return "redirect:account";
	
	
		
	}
		
	@RequestMapping(value = "/updatePassword", method=RequestMethod.POST)
	public String handlingLogin(HttpServletRequest arg0, HttpServletResponse arg1m,RedirectAttributes redirectAttributes,
		@RequestParam("pass") String passwordOld,@RequestParam("passn") String passwordNew, HttpSession session){
		if (session.getAttribute("loggedin") != null) {
			User u = (User)session.getAttribute("loggedin");
			System.out.println(u.toString());
			StringLib lib = new StringLib();
			if(u.getPassword().equals(lib.md5(passwordOld))) {
				User item = u;
				
				item.setPassword(lib.md5(passwordNew));
				UserDAO uDao = new UserDAO();
				uDao.updateUser(item);
				return "redirect:logout";
			}else {
				session.setAttribute("message", "Password false");
			}
		}
		return "redirect:account";
	}
		
}
