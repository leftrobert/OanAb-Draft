package vn.com.fsoft.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lib.StringLib;
import vn.com.fsoft.dao.LoginDAO;
import vn.com.fsoft.dao.UserDAO;
import vn.com.fsoft.model.Admin;
import vn.com.fsoft.model.User;

@Controller
public class LoginController{
	@RequestMapping(value = "/handlingLogin", method=RequestMethod.POST)
	public String handlingLogin(HttpServletRequest arg0, HttpServletResponse arg1m,RedirectAttributes redirectAttributes,
	@RequestParam("phone") String phone, @RequestParam("pass") String pass, HttpSession session){
//		System.out.println("login: " + phone + " " + pass);
		// TODO Auto-generated method stub
		LoginDAO ldao = new LoginDAO();
		StringLib strLib = new StringLib();
		pass = strLib.md5(pass);
		if(phone == "" || pass == "") {
			session.setAttribute("message", "Fill in the required field to continue");
			return "redirect:login";
		} else if (ldao.checkLogin(phone, pass)){
			User u = ldao.getUser(phone);
			session.setAttribute("loggedin", u);
			if (session.getAttribute("message") != null) session.removeAttribute("message");
			return "redirect:shop";
		} else {
			session.setAttribute("message", "Invalid credentials");
			return "redirect:login";
		}
	}
	

	@RequestMapping(value = "/handlingAdmin", method=RequestMethod.POST)
	public String handlingAdmin(HttpServletRequest arg0, HttpServletResponse arg1m,RedirectAttributes redirectAttributes,
	@RequestParam("admin") String admin, @RequestParam("pass") String pass, HttpSession session){
		System.out.println("admin login: " + admin + " " + pass);
		// TODO Auto-generated method stub
		LoginDAO ldao = new LoginDAO();
		if(admin == "" || pass == "") {
			session.setAttribute("message", "Fill in the required field to continue");
			return "redirect:admin";
		} else if (ldao.checkAdmin(admin, pass)){
			Admin a = ldao.getAdmin(admin);
			session.setAttribute("adminin", a);
			if (session.getAttribute("message") != null) session.removeAttribute("message");
			return "redirect:shop";
		} else {
			session.setAttribute("message", "Invalid credentials");
			return "redirect:admin";
		}
	}

	@RequestMapping(value = "/logout", method=RequestMethod.GET)
	public String logout(HttpServletRequest arg0, HttpServletResponse arg1m, RedirectAttributes redirectAttributes,
	HttpSession session){
		if (session.getAttribute("loggedin") != null) {
			session.removeAttribute("loggedin");
		}
		if (session.getAttribute("adminin") != null) {
			session.removeAttribute("adminin");
		}
		return "redirect:index";
	}
}
