package vn.com.fsoft.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

import vn.com.fsoft.model.User;
import vn.com.fsoft.util.HibernateUtil;

import java.util.ArrayList;
import java.util.List;

public class UserDAO {
	Session session = null;
	
	public ArrayList<User> getList(){
		session = HibernateUtil.getSessionFactory().openSession();
        //session.beginTransaction();
        String sql = "From User u ";
        Query query = session.createQuery(sql);
        
        ArrayList<User> list =  (ArrayList<User>)query.list();
        if (list.size() > 0) {
        	session.close();
            return list;
        }
        session.close();
        return null;
	}
	public int updateUser(User u){
		int result = 0;
		session = HibernateUtil.getSessionFactory().openSession();
        try {
        	session.beginTransaction();
//        	User user = (User)session.get(User.class, u.getId());
//        	user.setName(u.getName());
        	session.update(u);
    		session.getTransaction().commit();
		} catch (HibernateException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
        finally {
        	session.close();
		}
        return result;
	}
	
}
